USE [master]
GO
/****** Object:  Database [TCs]    Script Date: 9/8/2021 8:18:11 AM ******/
/***		May need some changes for a new server // JALILVAND 	**/
CREATE DATABASE [TCs]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'TCs', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\TCs.mdf' , SIZE = 2731008KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'TCs_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\TCs_log.ldf' , SIZE = 1785856KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
ALTER DATABASE [TCs] SET COMPATIBILITY_LEVEL = 110
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [TCs].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [TCs] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [TCs] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [TCs] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [TCs] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [TCs] SET ARITHABORT OFF 
GO
ALTER DATABASE [TCs] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [TCs] SET AUTO_CREATE_STATISTICS ON 
GO
ALTER DATABASE [TCs] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [TCs] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [TCs] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [TCs] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [TCs] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [TCs] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [TCs] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [TCs] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [TCs] SET  DISABLE_BROKER 
GO
ALTER DATABASE [TCs] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [TCs] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [TCs] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [TCs] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [TCs] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [TCs] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [TCs] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [TCs] SET RECOVERY FULL 
GO
ALTER DATABASE [TCs] SET  MULTI_USER 
GO
ALTER DATABASE [TCs] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [TCs] SET DB_CHAINING OFF 
GO
ALTER DATABASE [TCs] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [TCs] SET TARGET_RECOVERY_TIME = 0 SECONDS 
GO
EXEC sys.sp_db_vardecimal_storage_format N'TCs', N'ON'
GO
USE [TCs]
GO
/****** Object:  User [NT AUTHORITY\SYSTEM]    Script Date: 9/8/2021 8:18:11 AM ******/
CREATE USER [NT AUTHORITY\SYSTEM] FOR LOGIN [NT AUTHORITY\SYSTEM] WITH DEFAULT_SCHEMA=[dbo]
GO
ALTER ROLE [db_owner] ADD MEMBER [NT AUTHORITY\SYSTEM]
GO
/****** Object:  Table [dbo].[data]    Script Date: 9/8/2021 8:18:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[data](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[mehvar_id] [varchar](6) NULL,
	[interval] [datetime] NULL,
	[acount] [int] NULL,
	[avavg] [int] NULL,
	[aspeed] [int] NULL,
	[agrab] [int] NULL,
	[aheadway] [int] NULL,
	[bcount] [int] NULL,
	[bvavg] [int] NULL,
	[bspeed] [int] NULL,
	[bgrab] [int] NULL,
	[bheadway] [int] NULL,
	[ccount] [int] NULL,
	[cvavg] [int] NULL,
	[cspeed] [int] NULL,
	[cgrab] [int] NULL,
	[cheadway] [int] NULL,
	[dcount] [int] NULL,
	[dvavg] [int] NULL,
	[dspeed] [int] NULL,
	[dgrab] [int] NULL,
	[dheadway] [int] NULL,
	[ecount] [int] NULL,
	[evavg] [int] NULL,
	[espeed] [int] NULL,
	[egrab] [int] NULL,
	[eheadway] [int] NULL,
	[xcount] [int] NULL,
	[xvavg] [int] NULL,
	[xspeed] [int] NULL,
	[xgrab] [int] NULL,
	[xheadway] [int] NULL,
	[count] [int] NULL,
	[vavg] [int] NULL,
	[speed] [int] NULL,
	[grab] [int] NULL,
	[headway] [int] NULL,
	[occ] [int] NULL,
	[vbat] [int] NULL,
	[vsol] [int] NULL,
	[errcode] [int] NULL,
	[p1] [int] NULL,
	[p2] [bigint] NULL,
	[p3] [bigint] NULL,
	[p4] [text] NULL,
	[p5] [bigint] NULL,
	[p6] [datetime] NULL,
	[p7] [bigint] NULL,
	[RMTO_ID] [bigint] NULL,
	[RMTO_FID] [bigint] NULL,
	[RMTO_CFL] [bigint] NULL,
	[RMTO_SRVDT] [datetime] NULL,
	[RMTO_DLY] [bigint] NULL,
	[RMTO_BIL] [int] NULL,
	[RMTO_ERR] [text] NULL,
	[processed] [smallint] NULL,
	[offpro] [smallint] NULL,
 CONSTRAINT [PK_data] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[data_int]    Script Date: 9/8/2021 8:18:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[data_int](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[device_id] [bigint] NULL,
	[interval] [datetime] NULL,
	[l1acount] [int] NULL,
	[l1avavg] [int] NULL,
	[l1aspeed] [int] NULL,
	[l1agrab] [int] NULL,
	[l1aheadway] [int] NULL,
	[l1bcount] [int] NULL,
	[l1bvavg] [int] NULL,
	[l1bspeed] [int] NULL,
	[l1bgrab] [int] NULL,
	[l1bheadway] [int] NULL,
	[l1ccount] [int] NULL,
	[l1cvavg] [int] NULL,
	[l1cspeed] [int] NULL,
	[l1cgrab] [int] NULL,
	[l1cheadway] [int] NULL,
	[l1dcount] [int] NULL,
	[l1dvavg] [int] NULL,
	[l1dspeed] [int] NULL,
	[l1dgrab] [int] NULL,
	[l1dheadway] [int] NULL,
	[l1ecount] [int] NULL,
	[l1evavg] [int] NULL,
	[l1espeed] [int] NULL,
	[l1egrab] [int] NULL,
	[l1eheadway] [int] NULL,
	[l1xcount] [int] NULL,
	[l1xvavg] [int] NULL,
	[l1xspeed] [int] NULL,
	[l1xgrab] [int] NULL,
	[l1xheadway] [int] NULL,
	[l1occ] [int] NULL,
	[l2acount] [int] NULL,
	[l2avavg] [int] NULL,
	[l2aspeed] [int] NULL,
	[l2agrab] [int] NULL,
	[l2aheadway] [int] NULL,
	[l2bcount] [int] NULL,
	[l2bvavg] [int] NULL,
	[l2bspeed] [int] NULL,
	[l2bgrab] [int] NULL,
	[l2bheadway] [int] NULL,
	[l2ccount] [int] NULL,
	[l2cvavg] [int] NULL,
	[l2cspeed] [int] NULL,
	[l2cgrab] [int] NULL,
	[l2cheadway] [int] NULL,
	[l2dcount] [int] NULL,
	[l2dvavg] [int] NULL,
	[l2dspeed] [int] NULL,
	[l2dgrab] [int] NULL,
	[l2dheadway] [int] NULL,
	[l2ecount] [int] NULL,
	[l2evavg] [int] NULL,
	[l2espeed] [int] NULL,
	[l2egrab] [int] NULL,
	[l2eheadway] [int] NULL,
	[l2xcount] [int] NULL,
	[l2xvavg] [int] NULL,
	[l2xspeed] [int] NULL,
	[l2xgrab] [int] NULL,
	[l2xheadway] [int] NULL,
	[l2occ] [int] NULL,
	[vbat] [int] NULL,
	[vsol] [int] NULL,
	[errcode] [int] NULL,
 CONSTRAINT [PK_data_int] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[device]    Script Date: 9/8/2021 8:18:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[device](
	[device_id] [bigint] IDENTITY(335,1) NOT NULL,
	[device_code] [varchar](8) NULL,
	[device_name] [text] NULL,
	[device_type] [smallint] NULL,
	[l1_mehvar] [varchar](6) NULL,
	[l2_mehvar] [varchar](6) NULL,
	[version] [varchar](15) NULL,
	[phone] [varchar](11) NULL,
 CONSTRAINT [PK_device] PRIMARY KEY CLUSTERED 
(
	[device_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[failure]    Script Date: 9/8/2021 8:18:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[failure](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[mehvar_code] [varchar](6) NULL,
	[start_fail] [datetime] NULL,
	[end_fail] [datetime] NULL,
	[failure_type] [smallint] NULL,
	[status] [smallint] NULL,
	[details] [text] NULL,
	[person] [varchar](255) NULL,
 CONSTRAINT [PK_failure] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[mehvar]    Script Date: 9/8/2021 8:18:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[mehvar](
	[mehvar_code] [varchar](6) NOT NULL,
	[mehvar_name] [ntext] NULL,
	[ostan] [smallint] NULL,
	[active] [smallint] NULL,
	[grab_count] [smallint] NULL,
	[lane_no] [smallint] NULL,
	[mehvar_type] [smallint] NULL,
	[cid] [int] NULL,
	[interval_p] [smallint] NULL,
	[lat] [float] NULL,
	[lng] [float] NULL,
	[addr] [ntext] NULL,
	[power] [smallint] NULL,
	[batteryamp] [int] NULL,
	[loopsize] [varchar](50) NULL,
	[details] [ntext] NULL,
	[ac] [float] NULL,
	[bc] [float] NULL,
	[cc] [float] NULL,
	[dc] [float] NULL,
	[ec] [float] NULL,
 CONSTRAINT [PK_mehvar] PRIMARY KEY CLUSTERED 
(
	[mehvar_code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[pairs]    Script Date: 9/8/2021 8:18:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[pairs](
	[device_id] [bigint] NOT NULL,
	[mehvar_id] [varchar](6) NULL,
 CONSTRAINT [PK_pairs] PRIMARY KEY CLUSTERED 
(
	[device_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [_dta_index_data_6_565577053__K3D_K2_1_4_5_6_7_8_9_10_11_12_13_14_15_16_17_18_19_20_21_22_23_24_25_26_27_28_29_30_31_32_33_34_]    Script Date: 9/8/2021 8:18:11 AM ******/
CREATE NONCLUSTERED INDEX [_dta_index_data_6_565577053__K3D_K2_1_4_5_6_7_8_9_10_11_12_13_14_15_16_17_18_19_20_21_22_23_24_25_26_27_28_29_30_31_32_33_34_] ON [dbo].[data]
(
	[interval] DESC,
	[mehvar_id] ASC
)
INCLUDE ( 	[id],
	[acount],
	[avavg],
	[aspeed],
	[agrab],
	[aheadway],
	[bcount],
	[bvavg],
	[bspeed],
	[bgrab],
	[bheadway],
	[ccount],
	[cvavg],
	[cspeed],
	[cgrab],
	[cheadway],
	[dcount],
	[dvavg],
	[dspeed],
	[dgrab],
	[dheadway],
	[ecount],
	[evavg],
	[espeed],
	[egrab],
	[eheadway],
	[xcount],
	[xvavg],
	[xspeed],
	[xgrab],
	[xheadway],
	[count],
	[vavg],
	[speed],
	[grab],
	[headway],
	[occ],
	[vbat],
	[vsol],
	[errcode],
	[p1],
	[p2],
	[p3],
	[p5],
	[p6],
	[p7],
	[RMTO_ID],
	[RMTO_FID],
	[RMTO_CFL],
	[RMTO_SRVDT],
	[RMTO_DLY],
	[RMTO_BIL],
	[processed]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [_dta_index_data_6_565577053__K50_K2]    Script Date: 9/8/2021 8:18:11 AM ******/
CREATE NONCLUSTERED INDEX [_dta_index_data_6_565577053__K50_K2] ON [dbo].[data]
(
	[RMTO_ID] ASC,
	[mehvar_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [_dta_index_data_6_565577053__K50_K57_K2_K1_K3_4_9_14_19_24]    Script Date: 9/8/2021 8:18:11 AM ******/
CREATE NONCLUSTERED INDEX [_dta_index_data_6_565577053__K50_K57_K2_K1_K3_4_9_14_19_24] ON [dbo].[data]
(
	[RMTO_ID] ASC,
	[processed] ASC,
	[mehvar_id] ASC,
	[id] ASC,
	[interval] ASC
)
INCLUDE ( 	[acount],
	[bcount],
	[ccount],
	[dcount],
	[ecount]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [_dta_index_data_6_565577053__K57_K58_K2_K3_1_4_5_6_7_8_9_10_11_12_13_14_15_16_17_18_19_20_21_22_23_24_25_26_27_28_29_30_31_32_]    Script Date: 9/8/2021 8:18:11 AM ******/
CREATE NONCLUSTERED INDEX [_dta_index_data_6_565577053__K57_K58_K2_K3_1_4_5_6_7_8_9_10_11_12_13_14_15_16_17_18_19_20_21_22_23_24_25_26_27_28_29_30_31_32_] ON [dbo].[data]
(
	[processed] ASC,
	[offpro] ASC,
	[mehvar_id] ASC,
	[interval] ASC
)
INCLUDE ( 	[id],
	[acount],
	[avavg],
	[aspeed],
	[agrab],
	[aheadway],
	[bcount],
	[bvavg],
	[bspeed],
	[bgrab],
	[bheadway],
	[ccount],
	[cvavg],
	[cspeed],
	[cgrab],
	[cheadway],
	[dcount],
	[dvavg],
	[dspeed],
	[dgrab],
	[dheadway],
	[ecount],
	[evavg],
	[espeed],
	[egrab],
	[eheadway],
	[xcount],
	[xvavg],
	[xspeed],
	[xgrab],
	[xheadway],
	[count],
	[vavg],
	[speed],
	[grab],
	[headway],
	[occ],
	[vbat],
	[vsol],
	[errcode],
	[p1],
	[p2],
	[p3],
	[p5],
	[p6],
	[p7],
	[RMTO_ID],
	[RMTO_FID],
	[RMTO_CFL],
	[RMTO_SRVDT],
	[RMTO_DLY],
	[RMTO_BIL]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [_dta_index_data_6_565577053__K58]    Script Date: 9/8/2021 8:18:11 AM ******/
CREATE NONCLUSTERED INDEX [_dta_index_data_6_565577053__K58] ON [dbo].[data]
(
	[offpro] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [_dta_index_data_6_565577053__K58_K3_1_2_4_5_6_7_8_9_10_11_12_13_14_15_16_17_18_19_20_21_22_23_24_25_26_27_28_29_30_31_32_33_34_]    Script Date: 9/8/2021 8:18:11 AM ******/
CREATE NONCLUSTERED INDEX [_dta_index_data_6_565577053__K58_K3_1_2_4_5_6_7_8_9_10_11_12_13_14_15_16_17_18_19_20_21_22_23_24_25_26_27_28_29_30_31_32_33_34_] ON [dbo].[data]
(
	[offpro] ASC,
	[interval] ASC
)
INCLUDE ( 	[id],
	[mehvar_id],
	[acount],
	[avavg],
	[aspeed],
	[agrab],
	[aheadway],
	[bcount],
	[bvavg],
	[bspeed],
	[bgrab],
	[bheadway],
	[ccount],
	[cvavg],
	[cspeed],
	[cgrab],
	[cheadway],
	[dcount],
	[dvavg],
	[dspeed],
	[dgrab],
	[dheadway],
	[ecount],
	[evavg],
	[espeed],
	[egrab],
	[eheadway],
	[xcount],
	[xvavg],
	[xspeed],
	[xgrab],
	[xheadway],
	[count],
	[vavg],
	[speed],
	[grab],
	[headway],
	[occ],
	[vbat],
	[vsol],
	[errcode],
	[p1],
	[p2],
	[p3],
	[p5],
	[p6],
	[p7],
	[RMTO_ID],
	[RMTO_FID],
	[RMTO_CFL],
	[RMTO_SRVDT],
	[RMTO_DLY],
	[RMTO_BIL],
	[processed]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [data_unq]    Script Date: 9/8/2021 8:18:11 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [data_unq] ON [dbo].[data]
(
	[mehvar_id] ASC,
	[interval] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [data_int_unq]    Script Date: 9/8/2021 8:18:11 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [data_int_unq] ON [dbo].[data_int]
(
	[device_id] ASC,
	[interval] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[data] ADD  CONSTRAINT [DF_data_offpro]  DEFAULT ((0)) FOR [offpro]
GO
ALTER TABLE [dbo].[mehvar] ADD  CONSTRAINT [DF_mehvar_ac]  DEFAULT ((1)) FOR [ac]
GO
ALTER TABLE [dbo].[mehvar] ADD  CONSTRAINT [DF_mehvar_bc]  DEFAULT ((1)) FOR [bc]
GO
ALTER TABLE [dbo].[mehvar] ADD  CONSTRAINT [DF_mehvar_cc]  DEFAULT ((1)) FOR [cc]
GO
ALTER TABLE [dbo].[mehvar] ADD  CONSTRAINT [DF_mehvar_dc]  DEFAULT ((1)) FOR [dc]
GO
ALTER TABLE [dbo].[mehvar] ADD  CONSTRAINT [DF_mehvar_ec]  DEFAULT ((1)) FOR [ec]
GO
USE [master]
GO
ALTER DATABASE [TCs] SET  READ_WRITE 
GO
