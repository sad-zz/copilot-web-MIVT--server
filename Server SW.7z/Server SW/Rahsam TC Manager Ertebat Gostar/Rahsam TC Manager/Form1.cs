﻿using System;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Data.SqlClient;
using System.Threading;
using System.ServiceModel;
using System.Globalization;
using System.IO;
using System.Data.Odbc;


namespace Rahsam_TC_Manager
{
    public partial class Form1 : Form
    {
        private Byte[] data = new Byte[2048];
        static ManualResetEvent allDone = new ManualResetEvent(false);
        static bool mainThreadStop = false;
        static TcpListener myListener = null;
        static int port = 0;
        static bool is_dubg = false;
        public struct single_car
        {
            public int speed;
            public int vclass;
            public DateTime passdate;
            public int line;
            public bool speedt;
            public int grabt;
            public bool headwayt;
            public int rndsorter;
        }
        //
        public Form1()
        {
            InitializeComponent();
        }
        public struct RMTO5Data
        {
            public ushort CID;
            public string UID;
            public string PWD;
            public uint FID;
            public uint RID;
            public System.DateTime ST;
            public System.DateTime ET;
            public System.Nullable<ushort> C1;
            public System.Nullable<ushort> C2;
            public System.Nullable<ushort> C3;
            public System.Nullable<ushort> C4;
            public System.Nullable<ushort> C5;
            public System.Nullable<ushort> ASP;
            public System.Nullable<ushort> S1;
            public System.Nullable<ushort> S2;
            public System.Nullable<ushort> S3;
            public System.Nullable<ushort> S4;
            public System.Nullable<ushort> S5;
            public System.Nullable<ushort> SSO;
            public System.Nullable<ushort> SO1;
            public System.Nullable<ushort> SO2;
            public System.Nullable<ushort> SO3;
            public System.Nullable<ushort> SO4;
            public System.Nullable<ushort> SO5;
            public System.Nullable<ushort> OO;
            public System.Nullable<ushort> ESD;
        }
        public static class global
        {
            public static SqlDataReader dbres = null;
            public static SqlCommand cmd = null;
            public static bool keepgoing = true;
            public static Socket sazman_sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            public static string constring = "";
            public static int intervalperiod = 10;
        }
        public static void rmto5cb(IAsyncResult ar)
        {
            try
            {
                RMTO.CompaniesSoap csclient = (RMTO.CompaniesSoap)ar.AsyncState;
                RMTO.Add5Response anss = new RMTO.Add5Response();
                anss = csclient.EndAdd5(ar);
                var ans = anss.Add5Result;
                if (ans.SRVDT.Year < 2010) ans.SRVDT = DateTime.Now;
                if (ans.ID > 0 || ans.CFL == 100)
                {
                    using (var con = new SqlConnection(global.constring))
                    {
                        string qstring = "UPDATE data SET " +
                            "RMTO_ID = " + ans.ID.ToString() + ", " +
                            "RMTO_FID = " + ans.FID.ToString() + ", " +
                            "RMTO_CFL = " + ans.CFL.ToString() + ", " +
                            "RMTO_SRVDT = '" + ans.SRVDT.ToString("yyyy-MM-ddTHH:mm:ss") + "', " +
                            "RMTO_DLY = " + ans.DLY.ToString() + ", " +
                            "RMTO_BIL = " + ans.BIL.ToString() + ", " +
                            "RMTO_ERR = '" + ans.ERR + "' " +
                            "WHERE (id = " + ans.FID.ToString() + ")";
                        SqlDataAdapter adp1 = new SqlDataAdapter(qstring, con);
                        DataSet curr_data1 = new DataSet();
                        adp1.Fill(curr_data1, "Data");

                    }
                }
                else if (ans.ERR != "Exception")
                {
                    using (var con = new SqlConnection(global.constring))
                    {
                        string qstring = "UPDATE data SET " +
                            "RMTO_ID = 6735, " +
                            "RMTO_FID = " + ans.FID.ToString() + ", " +
                            "RMTO_CFL = " + ans.CFL.ToString() + ", " +
                            "RMTO_SRVDT = '" + ans.SRVDT.ToString("yyyy-MM-ddTHH:mm:ss") + "', " +
                            "RMTO_DLY = " + ans.DLY.ToString() + ", " +
                            "RMTO_BIL = " + ans.BIL.ToString() + ", " +
                            "RMTO_ERR = '" + ans.ERR + "' " +
                            "WHERE (id = " + ans.FID.ToString() + ")";
                        SqlDataAdapter adp1 = new SqlDataAdapter(qstring, con);
                        DataSet curr_data1 = new DataSet();
                        adp1.Fill(curr_data1, "Data");
                    }
                }
            }
            catch(Exception ss)
            {
                if(is_dubg) MessageBox.Show(ss.ToString());
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            AppDomain currentDomain = AppDomain.CurrentDomain;
            currentDomain.UnhandledException += new UnhandledExceptionEventHandler(MyHandler);
            global.constring = "Data Source=.\\;Database=TCs;Integrated Security=True;Connect Timeout=30;User Instance=False";
            myListener = new TcpListener(IPAddress.Any, 8099);
            Thread mainThread = new Thread(new ThreadStart(Run));
            mainThread.Start();
            ThreadStart rmto5thstart = new ThreadStart(RMTO5Thread);
            Thread rmto5th = new Thread(rmto5thstart);
            rmto5th.Start();
            ThreadStart offline_gen = new ThreadStart(offline_genf);
            Thread offgen = new Thread(offline_gen);
            offgen.Start();

        }
        static void MyHandler(object sender, UnhandledExceptionEventArgs args)
        {
            if (is_dubg)
            {
                Exception e = (Exception)args.ExceptionObject;
                MessageBox.Show("MyHandler caught : " + e.Message);
            }
        }
        public void Run()
        {
            try
            {

                myListener.Start();
                while (!mainThreadStop)
                {
                    Socket newsock = myListener.AcceptSocket();
                    new Thread(delegate()
                    {
                        startHandle(newsock);
                    }).Start();
                }
            }
            catch (Exception e)
            {
                if(is_dubg) MessageBox.Show(e.Message);
            }
        }

        private void generate_offline(Int32 mehvar,DateTime start, DateTime end,
            int acounti, int avavgi, int aspeedi, int agrabi,
            int bcounti, int bvavgi, int bspeedi, int bgrabi,
            int ccounti, int cvavgi, int cspeedi, int cgrabi,
            int dcounti, int dvavgi, int dspeedi, int dgrabi,
            int ecounti, int evavgi, int espeedi, int egrabi,
            int mehvar_type, int lane, bool grab_allow
            )
        {

            {

                PersianCalendar ps = new PersianCalendar();
                try
                {
                    
                    {
                        {

                            single_car[] everycars = new single_car[acounti + bcounti + ccounti + dcounti + ecounti];
                            Random rndcounter = new Random();



                            int rnd = 0;
                            int mojazs = 0;
                            int mojazl = 0;
                            if (mehvar_type == 1) { mojazs = 95; mojazl = 95; }
                            else if (mehvar_type == 2) { mojazs = 110; mojazl = 100; }
                            else if (mehvar_type == 3) { mojazs = 120; mojazl = 110; }
                            int ivmax = (int)(1.5 * (double)mojazs);
                            int ivmin = 5;
                            int total_car = acounti + bcounti + ccounti + dcounti + ecounti;
                            int i = 0;
                            for (i = 0; i < acounti; i++)
                            {
                                everycars[i].vclass = 1;
                                if (i < agrabi && grab_allow) everycars[i].grabt = 1;
                                else everycars[i].grabt = 0;
                                if (i < 2 * (aspeedi - 1))
                                {
                                    if (i % 2 == 0)
                                    {
                                        rnd = mojazs - avavgi + (rndcounter.Next() % Math.Max(1, ivmax - mojazs));
                                        everycars[i].speed = mojazs + rnd;
                                    }
                                    else
                                    {
                                        everycars[i].speed = mojazs - rnd;
                                    }
                                }
                                else
                                {
                                    if (i % 2 == 0)
                                    {
                                        rnd = rndcounter.Next() % Math.Max(1, (Math.Min(mojazs - avavgi, avavgi - ivmin)));
                                        everycars[i].speed = avavgi + rnd;
                                    }
                                    else
                                    {
                                        everycars[i].speed = avavgi - rnd;
                                    }
                                }
                            }
                            for (i = acounti; i < acounti + bcounti; i++)
                            {
                                everycars[i].vclass = 2;
                                if (i < bgrabi && grab_allow) everycars[i].grabt = 1;
                                else everycars[i].grabt = 0;
                                if (i < 2 * (bspeedi - 1))
                                {
                                    if (i % 2 == 0)
                                    {
                                        rnd = mojazl - bvavgi + (rndcounter.Next() % Math.Max(1, ivmax - mojazl));
                                        everycars[i].speed = mojazl + rnd;
                                    }
                                    else
                                    {
                                        everycars[i].speed = mojazl - rnd;
                                    }
                                }
                                else
                                {
                                    if (i % 2 == 0)
                                    {
                                        rnd = rndcounter.Next() % Math.Max(1, (Math.Min(mojazl - bvavgi, bvavgi - ivmin)));
                                        everycars[i].speed = bvavgi + rnd;
                                    }
                                    else
                                    {
                                        everycars[i].speed = bvavgi - rnd;
                                    }
                                }
                            }
                            for (i = acounti + bcounti; i < acounti + bcounti + ccounti; i++)
                            {
                                everycars[i].vclass = 3;
                                if (i < cgrabi && grab_allow) everycars[i].grabt = 1;
                                else everycars[i].grabt = 0;
                                if (i < 2 * (cspeedi - 1))
                                {
                                    if (i % 2 == 0)
                                    {
                                        rnd = mojazl - cvavgi + (rndcounter.Next() % Math.Max(1, ivmax - mojazl));
                                        everycars[i].speed = mojazl + rnd;
                                    }
                                    else
                                    {
                                        everycars[i].speed = mojazl - rnd;
                                    }
                                }
                                else
                                {
                                    if (i % 2 == 0)
                                    {
                                        rnd = rndcounter.Next() % Math.Max(1, (Math.Min(mojazl - cvavgi, cvavgi - ivmin)));
                                        everycars[i].speed = cvavgi + rnd;
                                    }
                                    else
                                    {
                                        everycars[i].speed = cvavgi - rnd;
                                    }
                                }
                            }
                            for (i = acounti + bcounti + ccounti; i < acounti + bcounti + ccounti + dcounti; i++)
                            {
                                everycars[i].vclass = 4;
                                if (i < dgrabi && grab_allow) everycars[i].grabt = 1;
                                else everycars[i].grabt = 0;
                                if (i < 2 * (dspeedi - 1))
                                {
                                    if (i % 2 == 0)
                                    {
                                        rnd = mojazl - dvavgi + (rndcounter.Next() % Math.Max(1, ivmax - mojazl));
                                        everycars[i].speed = mojazl + rnd;
                                    }
                                    else
                                    {
                                        everycars[i].speed = mojazl - rnd;
                                    }
                                }
                                else
                                {
                                    if (i % 2 == 0)
                                    {
                                        rnd = rndcounter.Next() % Math.Max(1, (Math.Min(mojazl - dvavgi, dvavgi - ivmin)));
                                        everycars[i].speed = dvavgi + rnd;
                                    }
                                    else
                                    {
                                        everycars[i].speed = dvavgi - rnd;
                                    }
                                }
                            }
                            for (i = acounti + bcounti + ccounti + dcounti; i < acounti + bcounti + ccounti + dcounti + ecounti; i++)
                            {
                                everycars[i].vclass = 5;
                                if (i < egrabi && grab_allow) everycars[i].grabt = 1;
                                else everycars[i].grabt = 0;
                                if (i < 2 * (espeedi - 1))
                                {
                                    if (i % 2 == 0)
                                    {
                                        rnd = mojazl - evavgi + (rndcounter.Next() % Math.Max(1, ivmax - mojazl));
                                        everycars[i].speed = mojazl + rnd;
                                    }
                                    else
                                    {
                                        everycars[i].speed = mojazl - rnd;
                                    }
                                }
                                else
                                {
                                    if (i % 2 == 0)
                                    {
                                        rnd = rndcounter.Next() % Math.Max(1, (Math.Min(mojazl - evavgi, evavgi - ivmin)));
                                        everycars[i].speed = evavgi + rnd;
                                    }
                                    else
                                    {
                                        everycars[i].speed = evavgi - rnd;
                                    }
                                }
                            }


                            for (i = 0; i < total_car; i++)
                            {
                                everycars[i].speed = Math.Max(0, everycars[i].speed);
                                everycars[i].rndsorter = rndcounter.Next() % 1000;
                            }
                            Array.Sort<single_car>(everycars, (x, y) => x.rndsorter.CompareTo(y.rndsorter));
                            for (i = 0; i < total_car; i++)
                            {
                                TimeSpan span = end - start;
                                int ms = (int)span.TotalMilliseconds;
                                rnd = rndcounter.Next(0, ms);
                                everycars[i].passdate = end.AddMilliseconds(-rnd);
                            }
                            Array.Sort<single_car>(everycars, (x, y) => x.passdate.CompareTo(y.passdate));
                            using (StreamWriter writer =
                            new StreamWriter("C:\\TC\\Offline\\" + ps.GetYear(start).ToString("D4") + "\\" + ps.GetMonth(start).ToString("D2") + "\\" + mehvar.ToString() + ".txt", true))
                            {
                                for (i = 0; i < total_car; i++)
                                {
                                    writer.WriteLine(everycars[i].passdate.ToString("yyyy-MM-dd HH:mm:ss.fff") + "," +
                                        everycars[i].vclass.ToString() + "," +
                                        (rndcounter.Next(1, lane + 1)).ToString() + "," +
                                        everycars[i].speed.ToString("D3") + "," +
                                        Convert.ToInt16(everycars[i].grabt).ToString()
                                        );
                                }

                            }
                        }
                    }
                }
                catch (Exception ss)
                {
                    if(is_dubg) MessageBox.Show(ss.ToString());
                }
            }
        }
        public void offline_genf()
        {
           
                SqlDataAdapter adp = null;
                DataSet curr_data = null;
                string querystring = "";
                int last = 0;
                while (!mainThreadStop)
                {
                try
                {
                    using (var con = new SqlConnection(global.constring))
                    {
                        querystring = "SELECT top(500) dt.*,mh.mehvar_type,mh.lane_no,mh.active,mh.interval_p,mh.grab_count,mh.cid FROM data as dt inner join mehvar as mh on mh.mehvar_code = dt.mehvar_id WHERE processed = 1  and offpro=0 order by dt.interval asc";
                        adp = new SqlDataAdapter(querystring, con);
                        curr_data = new DataSet();
                        adp.Fill(curr_data, "Data");
                    }
                    last = curr_data.Tables["Data"].Rows.Count;
                    for (int j = 0; j < last; j++)
                    {
                        if (mainThreadStop) break;
                        RMTO5Data rmtodata = new RMTO5Data();
                        short isnull = 0;
                        bool interval_period5 = false;
                        if (Convert.ToInt16(curr_data.Tables["Data"].Rows[j]["interval_p"]) == 5)
                            interval_period5 = true;
                        rmtodata.FID = Convert.ToUInt32(curr_data.Tables["Data"].Rows[j]["id"]);
                        rmtodata.RID = Convert.ToUInt32(curr_data.Tables["Data"].Rows[j]["mehvar_id"]);
                        rmtodata.ET = Convert.ToDateTime(curr_data.Tables["Data"].Rows[j]["interval"]);
                        if (!interval_period5)
                            rmtodata.ST = rmtodata.ET.AddMinutes(-global.intervalperiod);
                        else
                            rmtodata.ST = rmtodata.ET.AddMinutes(-5);

                        rmtodata.C1 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["acount"]);
                        rmtodata.C2 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["bcount"]);
                        rmtodata.C3 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["ccount"]);
                        rmtodata.C4 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["dcount"]);
                        rmtodata.C5 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["ecount"]);

                        rmtodata.S1 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["avavg"]);
                        rmtodata.S2 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["bvavg"]);
                        rmtodata.S3 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["cvavg"]);
                        rmtodata.S4 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["dvavg"]);
                        rmtodata.S5 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["evavg"]);

                        rmtodata.SO1 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["aspeed"]);
                        rmtodata.SO2 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["bspeed"]);
                        rmtodata.SO3 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["cspeed"]);
                        rmtodata.SO4 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["dspeed"]);
                        rmtodata.SO5 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["espeed"]);
                        if (rmtodata.C1 == 0) { rmtodata.S1 = 0; rmtodata.SO1 = 0; }
                        if (rmtodata.C2 == 0) { rmtodata.S2 = 0; rmtodata.SO2 = 0; }
                        if (rmtodata.C3 == 0) { rmtodata.S3 = 0; rmtodata.SO3 = 0; }
                        if (rmtodata.C4 == 0) { rmtodata.S4 = 0; rmtodata.SO4 = 0; }
                        if (rmtodata.C5 == 0) { rmtodata.S5 = 0; rmtodata.SO5 = 0; }
                        var sum = rmtodata.C1 + rmtodata.C2 + rmtodata.C3 + rmtodata.C4 + rmtodata.C5;
                        if (sum == 0) sum = 1;

                        rmtodata.ASP = (ushort)((
                            rmtodata.C1 * rmtodata.S1 +
                            rmtodata.C2 * rmtodata.S2 +
                            rmtodata.C3 * rmtodata.S3 +
                            rmtodata.C4 * rmtodata.S4 +
                            rmtodata.C5 * rmtodata.S5
                            ) / (sum));
                        rmtodata.SSO = (ushort)(rmtodata.SO1 + rmtodata.SO2 + rmtodata.SO3 + rmtodata.SO4 + rmtodata.SO5);
                        if (Convert.ToInt16(curr_data.Tables["Data"].Rows[j]["grab_count"]) == 1) rmtodata.OO = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["grab"]);
                        else rmtodata.OO = 0;
                        rmtodata.ESD = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["headway"]);

                        generate_offline(Convert.ToInt32(rmtodata.RID), rmtodata.ST, rmtodata.ET,
                                            Convert.ToInt16(rmtodata.C1), Convert.ToInt16(rmtodata.S1), Convert.ToInt16(rmtodata.SO1), Convert.ToInt16(curr_data.Tables["Data"].Rows[j]["agrab"]),
                                            Convert.ToInt16(rmtodata.C2), Convert.ToInt16(rmtodata.S2), Convert.ToInt16(rmtodata.SO2), Convert.ToInt16(curr_data.Tables["Data"].Rows[j]["bgrab"]),
                                            Convert.ToInt16(rmtodata.C3), Convert.ToInt16(rmtodata.S3), Convert.ToInt16(rmtodata.SO3), Convert.ToInt16(curr_data.Tables["Data"].Rows[j]["cgrab"]),
                                            Convert.ToInt16(rmtodata.C4), Convert.ToInt16(rmtodata.S4), Convert.ToInt16(rmtodata.SO4), Convert.ToInt16(curr_data.Tables["Data"].Rows[j]["dgrab"]),
                                            Convert.ToInt16(rmtodata.C5), Convert.ToInt16(rmtodata.S5), Convert.ToInt16(rmtodata.SO5), Convert.ToInt16(curr_data.Tables["Data"].Rows[j]["egrab"]),
                                            Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["mehvar_type"]),
                                            Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["lane_no"]),
                                            Convert.ToBoolean(curr_data.Tables["Data"].Rows[j]["grab_count"]));
                        using (var conx = new SqlConnection(global.constring))
                        {
                            string querystringx = "update data set offpro = 1 where id = " + rmtodata.FID.ToString();
                            SqlDataAdapter adpx = new SqlDataAdapter(querystringx, conx);
                            DataSet curr_datax = new DataSet();
                            adpx.Fill(curr_datax, "Data");
                        }
                    }
                }
                catch (Exception ss)
                {
                    if (is_dubg) MessageBox.Show(ss.ToString());
                }
            }
            
        }
        public void RMTO5Thread()
        {
            while (true)
            {
                try
                {
                    SqlDataAdapter adp = null;
                    DataSet curr_data = null;
                    string querystring = "";
                    Thread.Sleep(250);
                    short[] day_speed = new short[500];
                    short[] night_speed = new short[500];
                    int[] l1_mehvar = new int[500];
                    int[] l2_mehvar = new int[500];
                    int[] l1_sorat = new int[500];
                    int[] l2_sorat = new int[500];
                    int[] device_id = new int[500];
                    short[] type = new short[500];
                    long id = 0;
                    int last = 0;
                    while (!mainThreadStop)
                    {
                        try
                        {
                            SqlDataAdapter mhadp = new SqlDataAdapter();
                            DataSet mhcurr_data = new DataSet();
                            using (var con = new SqlConnection(global.constring))
                            {
                                querystring = "SELECT top(500) dt.id,dt.acount,dt.bcount,dt.ccount,dt.dcount,dt.ecount,mh.ac,mh.bc,mh.cc,mh.dc,mh.ec FROM data as dt inner join mehvar as mh on mh.mehvar_code = dt.mehvar_id WHERE RMTO_ID IS NULL and processed = 0 order by dt.interval asc";
                                mhadp = new SqlDataAdapter(querystring, con);
                                mhcurr_data = new DataSet();
                                mhadp.Fill(mhcurr_data, "Data");
                            }
                            for (int j = 0; j < mhcurr_data.Tables["Data"].Rows.Count; j++)
                            {
                                using (var con = new SqlConnection(global.constring))
                                {
                                    querystring = "update data set " +
                                        "acount = " + (Convert.ToDouble(mhcurr_data.Tables["Data"].Rows[j]["acount"]) * Convert.ToDouble(mhcurr_data.Tables["Data"].Rows[j]["ac"])).ToString() + ", " +
                                        "bcount = " + (Convert.ToDouble(mhcurr_data.Tables["Data"].Rows[j]["bcount"]) * Convert.ToDouble(mhcurr_data.Tables["Data"].Rows[j]["bc"])).ToString() + ", " +
                                        "ccount = " + (Convert.ToDouble(mhcurr_data.Tables["Data"].Rows[j]["ccount"]) * Convert.ToDouble(mhcurr_data.Tables["Data"].Rows[j]["cc"])).ToString() + ", " +
                                        "dcount = " + (Convert.ToDouble(mhcurr_data.Tables["Data"].Rows[j]["dcount"]) * Convert.ToDouble(mhcurr_data.Tables["Data"].Rows[j]["dc"])).ToString() + ", " +
                                        "ecount = " + (Convert.ToDouble(mhcurr_data.Tables["Data"].Rows[j]["ecount"]) * Convert.ToDouble(mhcurr_data.Tables["Data"].Rows[j]["ec"])).ToString() + ", " +
                                        "processed = 1 " +
                                        "where id = " + mhcurr_data.Tables["Data"].Rows[j]["id"].ToString() + "";
                                    SqlDataAdapter tmpadp = new SqlDataAdapter(querystring, con);
                                    DataSet tmpdset = new DataSet();
                                    tmpadp.Fill(tmpdset, "Data");

                                }
                            }
                            using (var con = new SqlConnection(global.constring))
                            {
                                querystring = "SELECT top(500) dt.*,mh.mehvar_type,mh.lane_no,mh.active,mh.interval_p,mh.grab_count,mh.cid FROM data as dt inner join mehvar as mh on mh.mehvar_code = dt.mehvar_id WHERE RMTO_ID IS NULL and processed = 1 order by dt.interval asc";
                                adp = new SqlDataAdapter(querystring, con);
                                curr_data = new DataSet();
                                adp.Fill(curr_data, "Data");
                            }
                            last = curr_data.Tables["Data"].Rows.Count;
                            Uri address = new Uri("http://5.160.195.56/Companies/Companies.asmx");
                            EndpointAddress endpointAddress = new EndpointAddress(address);
                            System.ServiceModel.Channels.Binding bind = new BasicHttpBinding();
                            var csclient = new RMTO.CompaniesSoapClient(bind, endpointAddress);

                            for (int j = 0; j < last; j++)
                            {
                                if (mainThreadStop) break;
                                RMTO5Data rmtodata = new RMTO5Data();
                                short isnull = 0;
                                rmtodata.CID = Convert.ToByte(curr_data.Tables["Data"].Rows[j]["cid"]);
                                bool interval_period5 = false;
                                if (Convert.ToInt16(curr_data.Tables["Data"].Rows[j]["interval_p"]) == 5)
                                    interval_period5 = true;

                                {
                                    rmtodata.UID = "ERGSH";
                                    rmtodata.PWD = "E2&mi(G*p";
                                }

                                rmtodata.FID = Convert.ToUInt32(curr_data.Tables["Data"].Rows[j]["id"]);
                                rmtodata.RID = Convert.ToUInt32(curr_data.Tables["Data"].Rows[j]["mehvar_id"]);
                                rmtodata.ET = Convert.ToDateTime(curr_data.Tables["Data"].Rows[j]["interval"]);
                                if (!interval_period5)
                                    rmtodata.ST = rmtodata.ET.AddMinutes(-global.intervalperiod);
                                else
                                    rmtodata.ST = rmtodata.ET.AddMinutes(-5);

                                rmtodata.C1 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["acount"]);
                                rmtodata.C2 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["bcount"]);
                                rmtodata.C3 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["ccount"]);
                                rmtodata.C4 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["dcount"]);
                                rmtodata.C5 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["ecount"]);
                                if (rmtodata.C1 == 0 && rmtodata.C2 == 0 && rmtodata.C3 == 0 && rmtodata.C4 == 0 && rmtodata.C5 == 0 && Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["vbat"]) == 0) isnull = 1;
                                if (Convert.ToInt16(curr_data.Tables["Data"].Rows[j]["active"]) == 0) isnull = 1;
                                if (isnull == 0)
                                {
                                    rmtodata.S1 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["avavg"]);
                                    rmtodata.S2 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["bvavg"]);
                                    rmtodata.S3 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["cvavg"]);
                                    rmtodata.S4 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["dvavg"]);
                                    rmtodata.S5 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["evavg"]);
                                    rmtodata.SO1 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["aspeed"]);
                                    rmtodata.SO2 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["bspeed"]);
                                    rmtodata.SO3 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["cspeed"]);
                                    rmtodata.SO4 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["dspeed"]);
                                    rmtodata.SO5 = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["espeed"]);
                                    if (rmtodata.C1 == 0) { rmtodata.S1 = 0; rmtodata.SO1 = 0; }
                                    if (rmtodata.C2 == 0) { rmtodata.S2 = 0; rmtodata.SO2 = 0; }
                                    if (rmtodata.C3 == 0) { rmtodata.S3 = 0; rmtodata.SO3 = 0; }
                                    if (rmtodata.C4 == 0) { rmtodata.S4 = 0; rmtodata.SO4 = 0; }
                                    if (rmtodata.C5 == 0) { rmtodata.S5 = 0; rmtodata.SO5 = 0; }
                                    var sum = rmtodata.C1 + rmtodata.C2 + rmtodata.C3 + rmtodata.C4 + rmtodata.C5;
                                    if (sum == 0) sum = 1;

                                    rmtodata.ASP = (ushort)((
                                        rmtodata.C1 * rmtodata.S1 +
                                        rmtodata.C2 * rmtodata.S2 +
                                        rmtodata.C3 * rmtodata.S3 +
                                        rmtodata.C4 * rmtodata.S4 +
                                        rmtodata.C5 * rmtodata.S5
                                        ) / (sum));
                                    rmtodata.SSO = (ushort)(rmtodata.SO1 + rmtodata.SO2 + rmtodata.SO3 + rmtodata.SO4 + rmtodata.SO5);
                                    if (Convert.ToInt16(curr_data.Tables["Data"].Rows[j]["grab_count"]) == 1) rmtodata.OO = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["grab"]);
                                    else rmtodata.OO = 0;
                                    rmtodata.ESD = Convert.ToUInt16(curr_data.Tables["Data"].Rows[j]["headway"]);
                                }
                                if (isnull == 1)
                                {
                                    rmtodata.C1 = null;
                                    rmtodata.C2 = null;
                                    rmtodata.C3 = null;
                                    rmtodata.C4 = null;
                                    rmtodata.C5 = null;
                                    rmtodata.ASP = null;
                                    rmtodata.S1 = null;
                                    rmtodata.S2 = null;
                                    rmtodata.S3 = null;
                                    rmtodata.S4 = null;
                                    rmtodata.S5 = null;
                                    rmtodata.SSO = null;
                                    rmtodata.SO1 = null;
                                    rmtodata.SO2 = null;
                                    rmtodata.SO3 = null;
                                    rmtodata.SO4 = null;
                                    rmtodata.SO5 = null;
                                    rmtodata.OO = null;
                                    rmtodata.ESD = null;

                                }

                                RMTO.Re ans = new Rahsam_TC_Manager.RMTO.Re();

                                if (isnull == 0)
                                {

                                    try
                                    {
                                        AsyncCallback cb = new AsyncCallback(rmto5cb);
                                        IAsyncResult ar = csclient.BeginAdd5(rmtodata.CID, rmtodata.UID, rmtodata.PWD, rmtodata.FID, rmtodata.RID, rmtodata.ST,
                                            rmtodata.ET, rmtodata.C1, rmtodata.C2, rmtodata.C3, rmtodata.C4, rmtodata.C5,
                                            rmtodata.ASP, rmtodata.S1, rmtodata.S2, rmtodata.S3, rmtodata.S4, rmtodata.S5, rmtodata.SSO,
                                            rmtodata.SO1, rmtodata.SO2, rmtodata.SO3, rmtodata.SO4, rmtodata.SO5, rmtodata.OO, rmtodata.ESD, cb, csclient);
                                    }
                                    catch (Exception ss)
                                    {
                                        if (is_dubg) MessageBox.Show("45454" + ss.ToString());
                                    }


                                }
                                else
                                {
                                    using (var con = new SqlConnection(global.constring))
                                    {
                                        string qstring = "UPDATE data SET " +
                                            "RMTO_ID = 1, " +
                                            "RMTO_FID = 0, " +
                                            "RMTO_CFL = 0, " +
                                            "RMTO_SRVDT = '" + DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss") + "', " +
                                            "RMTO_DLY = 0, " +
                                            "RMTO_BIL = 0, " +
                                            "RMTO_ERR = 'NULL SENT' " +
                                            "WHERE (id = " + curr_data.Tables["Data"].Rows[j]["id"].ToString() + ")";
                                        SqlDataAdapter adp1 = new SqlDataAdapter(qstring, con);
                                        DataSet curr_data1 = new DataSet();
                                        adp1.Fill(curr_data1, "Data");
                                    }
                                }



                                Thread.Sleep(10);
                            }
                        }
                        catch (Exception ss)
                        {
                            if (is_dubg) MessageBox.Show("4" + ss.ToString());
                        }
                        Thread.Sleep(10000);

                    }
                }
                catch (Exception ss)
                {
                    if (is_dubg) MessageBox.Show(ss.Message);
                }
                Thread.Sleep(10000);
            }
        }
        public void startHandle(Socket hansock)
        {
            try
            {
                hansock.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, 60000);
                hansock.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, 60000);
                string querystring = "";
                long i = 0;
                int message_code = 0;
                string data = "";
                byte[] recvdata = new byte[1024];
                byte[] senddata = new byte[1024];
                byte validdevice = 0;
                hansock.Receive(recvdata);
                if (is_dubg) MessageBox.Show(Encoding.ASCII.GetString(recvdata));
                Thread.Sleep(2000);
                data = Encoding.ASCII.GetString(recvdata);
                message_code = Convert.ToInt16(data.Substring(0, 4));
                int device_code = Convert.ToInt32(data.Substring(25, 8));
                string device_ver = data.Substring(39, 15);
                bool int5min = false;
                if (Convert.ToChar(device_ver.Substring(12, 1)) == 'A')
                    int5min = true;
                DateTime cinterval = DateTime.Now;
                cinterval = cinterval.AddSeconds(-cinterval.Second);
                if (!int5min)
                    cinterval = cinterval.AddMinutes(-(cinterval.Minute % global.intervalperiod));
                else
                    cinterval = cinterval.AddMinutes(-(cinterval.Minute % 5));
                {
                    hansock.Send(Encoding.ASCII.GetBytes("0012" + DateTime.Now.ToString("yyMMddHHmmss") + "\x0D\x0A"));
                    hansock.Receive(recvdata);
                    Thread.Sleep(1000);
                }
                int device_id = 0;
                int device_type = 0;
                int mehvar_code1 = 0;
                int mehvar_code2 = 0;
                using (var con = new SqlConnection(global.constring))
                {
                    querystring = "SELECT * FROM device WHERE device_code = '" + device_code.ToString() + "'";
                    SqlDataAdapter adp = new SqlDataAdapter(querystring, con);
                    DataSet curr_data = new DataSet();
                    adp.Fill(curr_data, "Data");
                    if (curr_data.Tables["Data"].Rows.Count == 1)
                    {
                        validdevice = 1;
                        device_id = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["device_id"]);
                        device_type = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["device_type"]);
                        mehvar_code1 = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1_mehvar"]);
                        mehvar_code2 = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2_mehvar"]);
                    }
                        
                }
                if (validdevice == 1)
                {
                    SqlDataAdapter adp_count = null;
                    DataSet curr_data_count = null;
                    try
                    {

                        using (var con = new SqlConnection(global.constring))
                        {
                            querystring = "update device set version = '" + device_ver + "' WHERE device_id = " + device_id.ToString();
                            adp_count = new SqlDataAdapter(querystring, con);
                            curr_data_count = new DataSet();
                            adp_count.Fill(curr_data_count, "Data");
                        }
                    }
                    catch (Exception ss)
                    {
                        if(is_dubg) MessageBox.Show(ss.ToString());
                    }
                    try
                    {

                        using (var con = new SqlConnection(global.constring))
                        {
                            querystring = "SELECT top(1)* FROM data_int WHERE device_id = " + device_id.ToString() + " order by interval desc";
                            adp_count = new SqlDataAdapter(querystring, con);
                            curr_data_count = new DataSet();
                            adp_count.Fill(curr_data_count, "Data");
                        }
                    }
                    catch (Exception ss)
                    {

                    }
                    Int64 end_period = 0;
                    if (!int5min)
                    {
                        end_period = 43200;

                        if (Convert.ToInt16(curr_data_count.Tables["Data"].Rows.Count) != 0)
                        {
                            end_period = Convert.ToInt64((cinterval - Convert.ToDateTime(curr_data_count.Tables["Data"].Rows[0]["interval"])).TotalMinutes);
                            if (end_period > 43200) end_period = 43200;
                        }
                        end_period /= global.intervalperiod;
                    }
                    else
                    {
                        end_period = 86400;

                        if (Convert.ToInt16(curr_data_count.Tables["Data"].Rows.Count) != 0)
                        {
                            end_period = Convert.ToInt64((cinterval - Convert.ToDateTime(curr_data_count.Tables["Data"].Rows[0]["interval"])).TotalMinutes);
                            if (end_period > 86400) end_period = 86400;
                        }
                        end_period /= 5;
                    }

                    for (i = (end_period - 1); i > 0; i--)
                    {
                        if (mainThreadStop) break;
                        {
                            {
                                try
                                {
                                    try
                                    {
                                        {
                                            if (!int5min)
                                                hansock.Send(Encoding.ASCII.GetBytes("0197" + cinterval.AddMinutes(-global.intervalperiod * i).ToString("yyMMddHHmm") + "\x0D\x0A"));
                                            else
                                                hansock.Send(Encoding.ASCII.GetBytes("0197" + cinterval.AddMinutes(-5 * i).ToString("yyMMddHHmm") + "\x0D\x0A"));
                                        }
                                        hansock.Receive(recvdata);
                                    }
                                    catch (Exception ss)
                                    {
                                        if (is_dubg) MessageBox.Show("66" + ss.ToString());
                                        break;
                                    }

                                    

                                    data = Encoding.ASCII.GetString(recvdata);
                                    if (data.Length < 5)
                                    {
                                        hansock.Close();
                                        break;
                                    }
                                    DateTime interval = new DateTime(
                                        2000 + Convert.ToInt16(data.Substring(33, 2)),
                                        Convert.ToInt16(data.Substring(35, 2)),
                                        Convert.ToInt16(data.Substring(37, 2)),
                                        Convert.ToInt16(data.Substring(39, 2)),
                                        Convert.ToInt16(data.Substring(41, 2)),
                                        0
                                        );
                                    int l1acount = Convert.ToInt16(data.Substring(43, 4));
                                    int l1avavg = Convert.ToInt16(data.Substring(47, 3));
                                    int l1aspeed = Convert.ToInt16(data.Substring(50, 4));
                                    int l1agrab = Convert.ToInt16(data.Substring(54, 4));
                                    int l1aheadway = Convert.ToInt16(data.Substring(58, 4));

                                    int l1bcount = Convert.ToInt16(data.Substring(62, 4));
                                    int l1bvavg = Convert.ToInt16(data.Substring(66, 3));
                                    int l1bspeed = Convert.ToInt16(data.Substring(69, 4));
                                    int l1bgrab = Convert.ToInt16(data.Substring(73, 4));
                                    int l1bheadway = Convert.ToInt16(data.Substring(77, 4));

                                    int l1ccount = Convert.ToInt16(data.Substring(81, 4));
                                    int l1cvavg = Convert.ToInt16(data.Substring(85, 3));
                                    int l1cspeed = Convert.ToInt16(data.Substring(88, 4));
                                    int l1cgrab = Convert.ToInt16(data.Substring(92, 4));
                                    int l1cheadway = Convert.ToInt16(data.Substring(96, 4));

                                    int l1dcount = Convert.ToInt16(data.Substring(100, 4));
                                    int l1dvavg = Convert.ToInt16(data.Substring(104, 3));
                                    int l1dspeed = Convert.ToInt16(data.Substring(107, 4));
                                    int l1dgrab = Convert.ToInt16(data.Substring(111, 4));
                                    int l1dheadway = Convert.ToInt16(data.Substring(115, 4));

                                    int l1ecount = Convert.ToInt16(data.Substring(119, 4));
                                    int l1evavg = Convert.ToInt16(data.Substring(123, 3));
                                    int l1espeed = Convert.ToInt16(data.Substring(126, 4));
                                    int l1egrab = Convert.ToInt16(data.Substring(130, 4));
                                    int l1eheadway = Convert.ToInt16(data.Substring(134, 4));

                                    int l1xcount = Convert.ToInt16(data.Substring(138, 4));
                                    int l1xvavg = Convert.ToInt16(data.Substring(142, 3));
                                    int l1xspeed = Convert.ToInt16(data.Substring(145, 4));
                                    int l1xgrab = Convert.ToInt16(data.Substring(149, 4));
                                    int l1xheadway = Convert.ToInt16(data.Substring(153, 4));

                                    int l1occ = Convert.ToInt16(data.Substring(157, 3));

                                    int l2acount = Convert.ToInt16(data.Substring(160, 4));
                                    int l2avavg = Convert.ToInt16(data.Substring(164, 3));
                                    int l2aspeed = Convert.ToInt16(data.Substring(167, 4));
                                    int l2agrab = Convert.ToInt16(data.Substring(171, 4));
                                    int l2aheadway = Convert.ToInt16(data.Substring(175, 4));

                                    int l2bcount = Convert.ToInt16(data.Substring(179, 4));
                                    int l2bvavg = Convert.ToInt16(data.Substring(183, 3));
                                    int l2bspeed = Convert.ToInt16(data.Substring(186, 4));
                                    int l2bgrab = Convert.ToInt16(data.Substring(190, 4));
                                    int l2bheadway = Convert.ToInt16(data.Substring(194, 4));

                                    int l2ccount = Convert.ToInt16(data.Substring(198, 4));
                                    int l2cvavg = Convert.ToInt16(data.Substring(202, 3));
                                    int l2cspeed = Convert.ToInt16(data.Substring(205, 4));
                                    int l2cgrab = Convert.ToInt16(data.Substring(209, 4));
                                    int l2cheadway = Convert.ToInt16(data.Substring(213, 4));
                                    
                                    int l2dcount = Convert.ToInt16(data.Substring(217, 4));
                                    int l2dvavg = Convert.ToInt16(data.Substring(221, 3));
                                    int l2dspeed = Convert.ToInt16(data.Substring(224, 4));
                                    int l2dgrab = Convert.ToInt16(data.Substring(228, 4));
                                    int l2dheadway = Convert.ToInt16(data.Substring(232, 4));

                                    int l2ecount = Convert.ToInt16(data.Substring(236, 4));
                                    int l2evavg = Convert.ToInt16(data.Substring(240, 3));
                                    int l2espeed = Convert.ToInt16(data.Substring(243, 4));
                                    int l2egrab = Convert.ToInt16(data.Substring(247, 4));
                                    int l2eheadway = Convert.ToInt16(data.Substring(251, 4));

                                    int l2xcount = Convert.ToInt16(data.Substring(255, 4));
                                    int l2xvavg = Convert.ToInt16(data.Substring(259, 3));
                                    int l2xspeed = Convert.ToInt16(data.Substring(262, 4));
                                    int l2xgrab = Convert.ToInt16(data.Substring(266, 4));
                                    int l2xheadway = Convert.ToInt16(data.Substring(270, 4));

                                    int l2occ = Convert.ToInt16(data.Substring(274, 3));

                                    int vbat = Convert.ToInt16(data.Substring(277, 3));
                                    int vsol = Convert.ToInt16(data.Substring(280, 3));
                                    int errcode = Convert.ToInt16(data.Substring(283, 4));
                                    if (l2ccount > 0 && l2cvavg == 0)
                                    {
                                        l2cvavg = (
                                            l2acount * l2avavg +
                                            l2bcount * l2bvavg +
                                            l2dcount * l2dvavg +
                                            l2ecount * l2evavg) /
                                            (
                                            l2acount + l2bcount + l2dcount + l2ecount
                                            );
                                    }
                                    querystring = "INSERT INTO data_int ( " +
                                        "device_id, interval, " +
                                        "l1acount, l1avavg, l1aspeed, l1agrab, l1aheadway, " +
                                        "l1bcount, l1bvavg, l1bspeed, l1bgrab, l1bheadway, " +
                                        "l1ccount, l1cvavg, l1cspeed, l1cgrab, l1cheadway, " +
                                        "l1dcount, l1dvavg, l1dspeed, l1dgrab, l1dheadway, " +
                                        "l1ecount, l1evavg, l1espeed, l1egrab, l1eheadway, " +
                                        "l1xcount, l1xvavg, l1xspeed, l1xgrab, l1xheadway, " +
                                        "l1occ, " +
                                        "l2acount, l2avavg, l2aspeed, l2agrab, l2aheadway, " +
                                        "l2bcount, l2bvavg, l2bspeed, l2bgrab, l2bheadway, " +
                                        "l2ccount, l2cvavg, l2cspeed, l2cgrab, l2cheadway, " +
                                        "l2dcount, l2dvavg, l2dspeed, l2dgrab, l2dheadway, " +
                                        "l2ecount, l2evavg, l2espeed, l2egrab, l2eheadway, " +
                                        "l2xcount, l2xvavg, l2xspeed, l2xgrab, l2xheadway, " +
                                        "l2occ, " +
                                        "vbat, vsol, errcode " +
                                        ") VALUES ( " +
                                        device_id.ToString() + ", '" + interval.ToString("yyyy-MM-ddTHH:mm:00") + "', " +
                                        l1acount.ToString() + ", " + l1avavg.ToString() + ", " + l1aspeed.ToString() + ", " + l1agrab.ToString() + ", " + l1aheadway.ToString() + ", " +
                                        l1bcount.ToString() + ", " + l1bvavg.ToString() + ", " + l1bspeed.ToString() + ", " + l1bgrab.ToString() + ", " + l1bheadway.ToString() + ", " +
                                        l1ccount.ToString() + ", " + l1cvavg.ToString() + ", " + l1cspeed.ToString() + ", " + l1cgrab.ToString() + ", " + l1cheadway.ToString() + ", " +
                                        l1dcount.ToString() + ", " + l1dvavg.ToString() + ", " + l1dspeed.ToString() + ", " + l1dgrab.ToString() + ", " + l1dheadway.ToString() + ", " +
                                        l1ecount.ToString() + ", " + l1evavg.ToString() + ", " + l1espeed.ToString() + ", " + l1egrab.ToString() + ", " + l1eheadway.ToString() + ", " +
                                        l1xcount.ToString() + ", " + l1xvavg.ToString() + ", " + l1xspeed.ToString() + ", " + l1xgrab.ToString() + ", " + l1xheadway.ToString() + ", " +
                                        l1occ.ToString() + ", " +
                                        l2acount.ToString() + ", " + l2avavg.ToString() + ", " + l2aspeed.ToString() + ", " + l2agrab.ToString() + ", " + l2aheadway.ToString() + ", " +
                                        l2bcount.ToString() + ", " + l2bvavg.ToString() + ", " + l2bspeed.ToString() + ", " + l2bgrab.ToString() + ", " + l2bheadway.ToString() + ", " +
                                        l2ccount.ToString() + ", " + l2cvavg.ToString() + ", " + l2cspeed.ToString() + ", " + l2cgrab.ToString() + ", " + l2cheadway.ToString() + ", " +
                                        l2dcount.ToString() + ", " + l2dvavg.ToString() + ", " + l2dspeed.ToString() + ", " + l2dgrab.ToString() + ", " + l2dheadway.ToString() + ", " +
                                        l2ecount.ToString() + ", " + l2evavg.ToString() + ", " + l2espeed.ToString() + ", " + l2egrab.ToString() + ", " + l2eheadway.ToString() + ", " +
                                        l2xcount.ToString() + ", " + l2xvavg.ToString() + ", " + l2xspeed.ToString() + ", " + l2xgrab.ToString() + ", " + l2xheadway.ToString() + ", " +
                                        l2occ.ToString() + ", " +
                                        vbat.ToString() + ", " + vsol.ToString() + ", " + errcode.ToString() +
                                        ")";
                                    using (var con = new SqlConnection(global.constring))
                                    {
                                        try
                                        {
                                            SqlDataAdapter adp = new SqlDataAdapter(querystring, con);
                                            DataSet curr_data = new DataSet();
                                            adp.Fill(curr_data, "Data");
                                        }
                                        catch (Exception sd)
                                        {
                                            if (is_dubg) MessageBox.Show("77" + sd.Message);
                                        }
                                    }
                                    

                                    if (device_type == 1)
                                    {
                                        using (var con = new SqlConnection(global.constring))
                                        {
                                            
                                            int totalvavg = ((l1acount * l1avavg + l1bcount * l1bvavg + l1ccount * l1cvavg + l1dcount * l1dvavg + l1ecount * l1evavg) / (Math.Max(1, l1acount + l1bcount + l1ccount + l1dcount + l1ecount)));
                                            l1bvavg = Math.Min(totalvavg, l1bvavg);
                                            l1cvavg = Math.Min(totalvavg, l1cvavg);
                                            l1dvavg = Math.Min(totalvavg, l1dvavg);
                                            l1evavg = Math.Min(totalvavg, l1evavg);
                                            totalvavg = ((l1acount * l1avavg + l1bcount * l1bvavg + l1ccount * l1cvavg + l1dcount * l1dvavg + l1ecount * l1evavg) / (Math.Max(1, l1acount + l1bcount + l1ccount + l1dcount + l1ecount)));

                                            querystring = "INSERT INTO data ( " +
                                                "mehvar_id, interval, " +
                                                "acount, avavg, aspeed, agrab, aheadway, " +
                                                "bcount, bvavg, bspeed, bgrab, bheadway, " +
                                                "ccount, cvavg, cspeed, cgrab, cheadway, " +
                                                "dcount, dvavg, dspeed, dgrab, dheadway, " +
                                                "ecount, evavg, espeed, egrab, eheadway, " +
                                                "xcount, xvavg, xspeed, xgrab, xheadway, " +
                                                "count, vavg, speed, grab, headway, " +
                                                "occ, vbat, vsol, errcode, processed, offpro" +
                                                ") VALUES (" +
                                                mehvar_code1.ToString() + ",'" + interval.ToString("yyyy-MM-ddTHH:mm:00.000") + "', " +
                                                l1acount.ToString() + ", " + l1avavg.ToString() + ", " + l1aspeed.ToString() + ", " + l1agrab.ToString() + ", " + l1aheadway.ToString() + ", " +
                                                l1bcount.ToString() + ", " + l1bvavg.ToString() + ", " + l1bspeed.ToString() + ", " + l1bgrab.ToString() + ", " + l1bheadway.ToString() + ", " +
                                                l1ccount.ToString() + ", " + l1cvavg.ToString() + ", " + l1cspeed.ToString() + ", " + l1cgrab.ToString() + ", " + l1cheadway.ToString() + ", " +
                                                l1dcount.ToString() + ", " + l1dvavg.ToString() + ", " + l1dspeed.ToString() + ", " + l1dgrab.ToString() + ", " + l1dheadway.ToString() + ", " +
                                                l1ecount.ToString() + ", " + l1evavg.ToString() + ", " + l1espeed.ToString() + ", " + l1egrab.ToString() + ", " + l1eheadway.ToString() + ", " +
                                                l1xcount.ToString() + ", " + l1xvavg.ToString() + ", " + l1xspeed.ToString() + ", " + l1xgrab.ToString() + ", " + l1xheadway.ToString() + ", " +
                                                (l1acount + l1bcount + l1ccount + l1dcount + l1ecount).ToString() + ", " + totalvavg.ToString() + ", " + (l1aspeed + l1bspeed + l1cspeed + l1dspeed + l1espeed).ToString() + ", " + (l1agrab + l1bgrab + l1cgrab + l1dgrab + l1egrab).ToString() + ", " + (l1aheadway + l1bheadway + l1cheadway + l1dheadway + l1eheadway).ToString() + ", " +
                                                l1occ.ToString() + ", " + vbat.ToString() + ", " + vsol.ToString() + ", " + errcode.ToString() +
                                                ", 0,0)";
                                            SqlDataAdapter adp = new SqlDataAdapter(querystring, con);
                                            DataSet curr_data = new DataSet();
                                            adp.Fill(curr_data, "Data");
                                        }
                                        using (var con = new SqlConnection(global.constring))
                                        {
                                            int totalvavg = ((l2acount * l2avavg + l2bcount * l2bvavg + l2ccount * l2cvavg + l2dcount * l2dvavg + l2ecount * l2evavg) / (Math.Max(1, l2acount + l2bcount + l2ccount + l2dcount + l2ecount)));
                                            l2bvavg = Math.Min(totalvavg, l2bvavg);
                                            l2cvavg = Math.Min(totalvavg, l2cvavg);
                                            l2dvavg = Math.Min(totalvavg, l2dvavg);
                                            l2evavg = Math.Min(totalvavg, l2evavg);
                                            totalvavg = ((l2acount * l2avavg + l2bcount * l2bvavg + l2ccount * l2cvavg + l2dcount * l2dvavg + l2ecount * l2evavg) / (Math.Max(1, l2acount + l2bcount + l2ccount + l2dcount + l2ecount)));
                                            querystring = "INSERT INTO data ( " +
                                                "mehvar_id, interval, " +
                                                "acount, avavg, aspeed, agrab, aheadway, " +
                                                "bcount, bvavg, bspeed, bgrab, bheadway, " +
                                                "ccount, cvavg, cspeed, cgrab, cheadway, " +
                                                "dcount, dvavg, dspeed, dgrab, dheadway, " +
                                                "ecount, evavg, espeed, egrab, eheadway, " +
                                                "xcount, xvavg, xspeed, xgrab, xheadway, " +
                                                "count, vavg, speed, grab, headway, " +
                                                "occ, vbat, vsol, errcode, processed,offpro" +
                                                ") VALUES (" +
                                                mehvar_code2.ToString() + ",'" + interval.ToString("yyyy-MM-ddTHH:mm:00.000") + "', " +
                                                l2acount.ToString() + ", " + l2avavg.ToString() + ", " + l2aspeed.ToString() + ", " + l2agrab.ToString() + ", " + l2aheadway.ToString() + ", " +
                                                l2bcount.ToString() + ", " + l2bvavg.ToString() + ", " + l2bspeed.ToString() + ", " + l2bgrab.ToString() + ", " + l2bheadway.ToString() + ", " +
                                                l2ccount.ToString() + ", " + l2cvavg.ToString() + ", " + l2cspeed.ToString() + ", " + l2cgrab.ToString() + ", " + l2cheadway.ToString() + ", " +
                                                l2dcount.ToString() + ", " + l2dvavg.ToString() + ", " + l2dspeed.ToString() + ", " + l2dgrab.ToString() + ", " + l2dheadway.ToString() + ", " +
                                                l2ecount.ToString() + ", " + l2evavg.ToString() + ", " + l2espeed.ToString() + ", " + l2egrab.ToString() + ", " + l2eheadway.ToString() + ", " +
                                                l2xcount.ToString() + ", " + l2xvavg.ToString() + ", " + l2xspeed.ToString() + ", " + l2xgrab.ToString() + ", " + l2xheadway.ToString() + ", " +
                                                (l2acount + l2bcount + l2ccount + l2dcount + l2ecount).ToString() + ", " + ((l2acount * l2avavg + l2bcount * l2bvavg + l2ccount * l2cvavg + l2dcount * l2dvavg + l2ecount * l2evavg) / (Math.Max(1, l2acount + l2bcount + l2ccount + l2dcount + l2ecount))).ToString() + ", " + (l2aspeed + l2bspeed + l2cspeed + l2dspeed + l2espeed).ToString() + ", " + (l2agrab + l2bgrab + l2cgrab + l2dgrab + l2egrab).ToString() + ", " + (l2aheadway + l2bheadway + l2cheadway + l2dheadway + l2eheadway).ToString() + ", " +
                                                l2occ.ToString() + ", " + vbat.ToString() + ", " + vsol.ToString() + ", " + errcode.ToString() +
                                                ", 0,0)";
                                            SqlDataAdapter adp = new SqlDataAdapter(querystring, con);
                                            DataSet curr_data = new DataSet();
                                            adp.Fill(curr_data, "Data");
                                        }
                                    }
                                    else if (device_type == 2)
                                    {

                                        int totalvavg = ((l1acount * l1avavg + l1bcount * l1bvavg + l1ccount * l1cvavg + l1dcount * l1dvavg + l1ecount * l1evavg + l2acount * l2avavg + l2bcount * l2bvavg + l2ccount * l2cvavg + l2dcount * l2dvavg + l2ecount * l2evavg) / (Math.Max(1, l1acount + l1bcount + l1ccount + l1dcount + l1ecount + l2acount + l2bcount + l2ccount + l2dcount + l2ecount)));
                                        l1bvavg = Math.Min(totalvavg, l1bvavg);
                                        l1cvavg = Math.Min(totalvavg, l1cvavg);
                                        l1dvavg = Math.Min(totalvavg, l1dvavg);
                                        l1evavg = Math.Min(totalvavg, l1evavg);
                                        l2bvavg = Math.Min(totalvavg, l2bvavg);
                                        l2cvavg = Math.Min(totalvavg, l2cvavg);
                                        l2dvavg = Math.Min(totalvavg, l2dvavg);
                                        l2evavg = Math.Min(totalvavg, l2evavg);
                                        totalvavg = ((l1acount * l1avavg + l1bcount * l1bvavg + l1ccount * l1cvavg + l1dcount * l1dvavg + l1ecount * l1evavg + l2acount * l2avavg + l2bcount * l2bvavg + l2ccount * l2cvavg + l2dcount * l2dvavg + l2ecount * l2evavg) / (Math.Max(1, l1acount + l1bcount + l1ccount + l1dcount + l1ecount + l2acount + l2bcount + l2ccount + l2dcount + l2ecount)));
                                        using (var con = new SqlConnection(global.constring))
                                        {
                                            querystring = "INSERT INTO data ( " +
                                            "mehvar_id, interval, " +
                                            "acount, avavg, aspeed, agrab, aheadway, " +
                                            "bcount, bvavg, bspeed, bgrab, bheadway, " +
                                            "ccount, cvavg, cspeed, cgrab, cheadway, " +
                                            "dcount, dvavg, dspeed, dgrab, dheadway, " +
                                            "ecount, evavg, espeed, egrab, eheadway, " +
                                            "xcount, xvavg, xspeed, xgrab, xheadway, " +
                                            "count, vavg, speed, grab, headway, " +
                                            "occ, vbat, vsol, errcode, processed,offpro" +
                                            ") VALUES (" +
                                            mehvar_code1.ToString() + ",'" + interval.ToString("yyyy-MM-ddTHH:mm:00.000") + "', " +
                                            (l1acount + l2acount).ToString() + ", " + ((l1acount * l1avavg + l2acount * l2avavg) / (Math.Max(1, l1acount + l2acount))).ToString() + ", " + (l1aspeed + l2aspeed).ToString() + ", " + (l1agrab + l2agrab).ToString() + ", " + (l1aheadway + l2aheadway).ToString() + ", " +
                                            (l1bcount + l2bcount).ToString() + ", " + ((l1bcount * l1bvavg + l2bcount * l2bvavg) / (Math.Max(1, l1bcount + l2bcount))).ToString() + ", " + (l1bspeed + l2bspeed).ToString() + ", " + (l1bgrab + l2bgrab).ToString() + ", " + (l1bheadway + l2bheadway).ToString() + ", " +
                                            (l1ccount + l2ccount).ToString() + ", " + ((l1ccount * l1cvavg + l2ccount * l2cvavg) / (Math.Max(1, l1ccount + l2ccount))).ToString() + ", " + (l1cspeed + l2cspeed).ToString() + ", " + (l1cgrab + l2cgrab).ToString() + ", " + (l1cheadway + l2cheadway).ToString() + ", " +
                                            (l1dcount + l2dcount).ToString() + ", " + ((l1dcount * l1dvavg + l2dcount * l2dvavg) / (Math.Max(1, l1dcount + l2dcount))).ToString() + ", " + (l1dspeed + l2dspeed).ToString() + ", " + (l1dgrab + l2dgrab).ToString() + ", " + (l1dheadway + l2dheadway).ToString() + ", " +
                                            (l1ecount + l2ecount).ToString() + ", " + ((l1ecount * l1evavg + l2ecount * l2evavg) / (Math.Max(1, l1ecount + l2ecount))).ToString() + ", " + (l1espeed + l2espeed).ToString() + ", " + (l1egrab + l2egrab).ToString() + ", " + (l1eheadway + l2eheadway).ToString() + ", " +
                                            (l1xcount + l2xcount).ToString() + ", " + ((l1xcount * l1xvavg + l2xcount * l2xvavg) / (Math.Max(1, l1xcount + l2xcount))).ToString() + ", " + (l1xspeed + l2xspeed).ToString() + ", " + (l1xgrab + l2xgrab).ToString() + ", " + (l1xheadway + l2xheadway).ToString() + ", " +
                                            (l1acount + l1bcount + l1ccount + l1dcount + l1ecount + l2acount + l2bcount + l2ccount + l2dcount + l2ecount).ToString() + ", " + totalvavg.ToString() + ", " + (l1aspeed + l1bspeed + l1cspeed + l1dspeed + l1espeed + l2aspeed + l2bspeed + l2cspeed + l2dspeed + l2espeed).ToString() + ", " + (l1agrab + l1bgrab + l1cgrab + l1dgrab + l1egrab + l2agrab + l2bgrab + l2cgrab + l2dgrab + l2egrab).ToString() + ", " + (l1aheadway + l1bheadway + l1cheadway + l1dheadway + l1eheadway + l2aheadway + l2bheadway + l2cheadway + l2dheadway + l2eheadway).ToString() + ", " +
                                            ((l1occ + l2occ) / 2).ToString() + ", " + vbat.ToString() + ", " + vsol.ToString() + ", " + errcode.ToString() +
                                            ",0,0)";
                                            SqlDataAdapter adp = new SqlDataAdapter(querystring, con);
                                            DataSet curr_data = new DataSet();
                                            adp.Fill(curr_data, "Data");
                                        }
                                    }
                                    else if (device_type == 3)
                                    {
                                        using (var con = new SqlConnection(global.constring))
                                        {
                                            querystring = "select dt.*,pr.* from data_int as dt " +
                                                "inner join pairs as pr on pr.device_id = dt.device_id " +
                                                "and pr.mehvar_id = '" + mehvar_code1.ToString() + "' " +
                                                "and dt.interval = '" + interval.ToString("yyyy-MM-ddTHH:mm:00.000") + "'";
                                            SqlDataAdapter adp = new SqlDataAdapter(querystring, con);
                                            DataSet curr_data = new DataSet();
                                            adp.Fill(curr_data, "Data");
                                            if (curr_data.Tables["Data"].Rows.Count == 2)
                                            {

                                                using (var con2 = new SqlConnection(global.constring))
                                                {
                                                    try
                                                    {
                                                        int l11avavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1avavg"]);
                                                        int l11bvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bvavg"]);
                                                        int l11cvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cvavg"]);
                                                        int l11dvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dvavg"]);
                                                        int l11evavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1evavg"]);
                                                        int l12avavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2avavg"]);
                                                        int l12bvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bvavg"]);
                                                        int l12cvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cvavg"]);
                                                        int l12dvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dvavg"]);
                                                        int l12evavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2evavg"]);
                                                        int l21avavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1avavg"]);
                                                        int l21bvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bvavg"]);
                                                        int l21cvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cvavg"]);
                                                        int l21dvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dvavg"]);
                                                        int l21evavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1evavg"]);
                                                        int l22avavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2avavg"]);
                                                        int l22bvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bvavg"]);
                                                        int l22cvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cvavg"]);
                                                        int l22dvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dvavg"]);
                                                        int l22evavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2evavg"]);
                                                        int totalvavg = ((
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) * l11avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) * l12avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) * l11bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) * l12bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) * l11cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) * l12cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) * l11dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) * l12dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) * l11evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) * l12evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) * l21avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) * l22avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) * l21bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) * l22bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) * l21cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) * l22cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) * l21dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) * l22dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) * l21evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"]) * l22evavg) /
                                                              (Math.Max(1, (
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"])
                                                            ))));

                                                        l11bvavg = Math.Min(totalvavg, l11bvavg);
                                                        l11cvavg = Math.Min(totalvavg, l11cvavg);
                                                        l11dvavg = Math.Min(totalvavg, l11dvavg);
                                                        l11evavg = Math.Min(totalvavg, l11evavg);
                                                        l12bvavg = Math.Min(totalvavg, l12bvavg);
                                                        l12cvavg = Math.Min(totalvavg, l12cvavg);
                                                        l12dvavg = Math.Min(totalvavg, l12dvavg);
                                                        l12evavg = Math.Min(totalvavg, l12evavg);
                                                        l21bvavg = Math.Min(totalvavg, l21bvavg);
                                                        l21cvavg = Math.Min(totalvavg, l21cvavg);
                                                        l21dvavg = Math.Min(totalvavg, l21dvavg);
                                                        l21evavg = Math.Min(totalvavg, l21evavg);
                                                        l22bvavg = Math.Min(totalvavg, l22bvavg);
                                                        l22cvavg = Math.Min(totalvavg, l22cvavg);
                                                        l22dvavg = Math.Min(totalvavg, l22dvavg);
                                                        l22evavg = Math.Min(totalvavg, l22evavg);
                                                        totalvavg = ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) * l11avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) * l12avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) * l11bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) * l12bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) * l11cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) * l12cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) * l11dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) * l12dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) * l11evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) * l12evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) * l21avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) * l22avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) * l21bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) * l22bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) * l21cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) * l22cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) * l21dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) * l22dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) * l21evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"]) * l22evavg) /
                                                              (Math.Max(1, (
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"])
                                                            ))));
                                                        querystring = "INSERT INTO data ( " +
                                                            "mehvar_id, interval, " +
                                                            "acount, avavg, aspeed, agrab, aheadway, " +
                                                            "bcount, bvavg, bspeed, bgrab, bheadway, " +
                                                            "ccount, cvavg, cspeed, cgrab, cheadway, " +
                                                            "dcount, dvavg, dspeed, dgrab, dheadway, " +
                                                            "ecount, evavg, espeed, egrab, eheadway, " +
                                                            "xcount, xvavg, xspeed, xgrab, xheadway, " +
                                                            "count, vavg, speed, grab, headway, " +
                                                            "occ, vbat, vsol, errcode, processed,offpro" +
                                                            ") VALUES (" +
                                                            mehvar_code1.ToString() + ",'" + interval.ToString("yyyy-MM-ddTHH:mm:00.000") + "', " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"])).ToString() + ", " +
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1avavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2avavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1avavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2avavg"])) / (Math.Max(1, Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"])))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1aspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2aspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1aspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2aspeed"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1agrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2agrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1agrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2agrab"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1aheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2aheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1aheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2aheadway"])).ToString() + ", " +
                                                            //b
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"])).ToString() + ", " +
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) * l11bvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) * l12bvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) * l21bvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) * l22bvavg) / (Math.Max(1, Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"])))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bspeed"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bgrab"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bheadway"])).ToString() + ", " +
                                                            //c
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"])).ToString() + ", " +
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) * l11cvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) * l12cvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) * l21cvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) * l22cvavg) / (Math.Max(1, Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"])))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cspeed"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cgrab"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cheadway"])).ToString() + ", " +
                                                            //d
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"])).ToString() + ", " +
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) * l11dvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) * l12dvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) * l21dvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) * l22dvavg) / (Math.Max(1, Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"])))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dspeed"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dgrab"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dheadway"])).ToString() + ", " +
                                                            //e
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"])).ToString() + ", " +
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) * l11evavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) * l12evavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) * l21evavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"]) * l22evavg) / (Math.Max(1, Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"])))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1espeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2espeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1espeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2espeed"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1egrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2egrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1egrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2egrab"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1eheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2eheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1eheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2eheadway"])).ToString() + ", " +
                                                            //x
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xcount"])).ToString() + ", " +
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xcount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xvavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xcount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xvavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xcount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xvavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xcount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xvavg"])) / (Math.Max(1, Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xcount"])))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xspeed"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xgrab"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xheadway"])).ToString() + ", " +
                                                            //count
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"])).ToString() + ", " +
                                                            //vavg
                                                            totalvavg.ToString() + ", " +
                                                            //speed
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1aspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2aspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1espeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2espeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1aspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2aspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1espeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2espeed"])).ToString() + ", " +
                                                            //grab
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1agrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2agrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1egrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2egrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1agrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2agrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1egrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2egrab"])).ToString() + ", " +
                                                            //headway
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1aheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2aheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1eheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2eheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1aheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2aheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1eheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2eheadway"])).ToString() + ", " +
                                                            //occ
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1occ"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2occ"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1occ"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2occ"])) / 4
                                                            ).ToString() + ", " +
                                                            (Math.Min(Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["vbat"]), Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["vbat"]))).ToString() + ", " +
                                                            (Math.Max(Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["vsol"]), Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["vsol"]))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["errcode"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["errcode"])).ToString() + ",0,0)";
                                                        SqlDataAdapter adp2 = new SqlDataAdapter(querystring, con2);
                                                        DataSet curr_data2 = new DataSet();
                                                        adp2.Fill(curr_data2, "Data");
                                                    }
                                                    catch (Exception ss)
                                                    {
                                                        if (is_dubg) MessageBox.Show("88" + ss.Message);
                                                    }
                                                }
                                            }
                                        }

                                    }
                                    else if (device_type == 4)
                                    {
                                        //
                                        using (var con = new SqlConnection(global.constring))
                                        {
                                            querystring = "select dt.*,pr.* from data_int as dt " +
                                                "inner join pairs as pr on pr.device_id = dt.device_id " +
                                                "and pr.mehvar_id = '" + mehvar_code1.ToString() + "' " +
                                                "and dt.interval = '" + interval.ToString("yyyy-MM-ddTHH:mm:00.000") + "'";
                                            SqlDataAdapter adp = new SqlDataAdapter(querystring, con);
                                            DataSet curr_data = new DataSet();
                                            adp.Fill(curr_data, "Data");
                                            if (curr_data.Tables["Data"].Rows.Count == 3)
                                            {
                                                //

                                                using (var con2 = new SqlConnection(global.constring))
                                                {
                                                    try
                                                    {
                                                        int l11avavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1avavg"]);
                                                        int l11bvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bvavg"]);
                                                        int l11cvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cvavg"]);
                                                        int l11dvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dvavg"]);
                                                        int l11evavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1evavg"]);
                                                        int l12avavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2avavg"]);
                                                        int l12bvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bvavg"]);
                                                        int l12cvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cvavg"]);
                                                        int l12dvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dvavg"]);
                                                        int l12evavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2evavg"]);
                                                        int l21avavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1avavg"]);
                                                        int l21bvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bvavg"]);
                                                        int l21cvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cvavg"]);
                                                        int l21dvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dvavg"]);
                                                        int l21evavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1evavg"]);
                                                        int l22avavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2avavg"]);
                                                        int l22bvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bvavg"]);
                                                        int l22cvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cvavg"]);
                                                        int l22dvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dvavg"]);
                                                        int l22evavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2evavg"]);
                                                        int l31avavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1avavg"]);
                                                        int l31bvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bvavg"]);
                                                        int l31cvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1cvavg"]);
                                                        int l31dvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dvavg"]);
                                                        int l31evavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1evavg"]);
                                                        int l32avavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2avavg"]);
                                                        int l32bvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bvavg"]);
                                                        int l32cvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2cvavg"]);
                                                        int l32dvavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dvavg"]);
                                                        int l32evavg = Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2evavg"]);
                                                        int totalvavg = ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) * l11avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) * l12avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) * l11bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) * l12bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) * l11cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) * l12cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) * l11dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) * l12dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) * l11evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) * l12evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) * l21avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) * l22avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) * l21bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) * l22bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) * l21cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) * l22cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) * l21dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) * l22dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) * l21evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"]) * l22evavg+
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1acount"]) * l31avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2acount"]) * l32avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bcount"]) * l31bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bcount"]) * l32bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ccount"]) * l31cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ccount"]) * l32cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dcount"]) * l31dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dcount"]) * l32dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ecount"]) * l31evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ecount"]) * l32evavg
                                                              ) 
                                                              /
                                                              (Math.Max(1, (
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"])+
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2acount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ccount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ecount"])
                                                            ))));

                                                        l11bvavg = Math.Min(totalvavg, l11bvavg);
                                                        l11cvavg = Math.Min(totalvavg, l11cvavg);
                                                        l11dvavg = Math.Min(totalvavg, l11dvavg);
                                                        l11evavg = Math.Min(totalvavg, l11evavg);
                                                        l12bvavg = Math.Min(totalvavg, l12bvavg);
                                                        l12cvavg = Math.Min(totalvavg, l12cvavg);
                                                        l12dvavg = Math.Min(totalvavg, l12dvavg);
                                                        l12evavg = Math.Min(totalvavg, l12evavg);
                                                        l21bvavg = Math.Min(totalvavg, l21bvavg);
                                                        l21cvavg = Math.Min(totalvavg, l21cvavg);
                                                        l21dvavg = Math.Min(totalvavg, l21dvavg);
                                                        l21evavg = Math.Min(totalvavg, l21evavg);
                                                        l22bvavg = Math.Min(totalvavg, l22bvavg);
                                                        l22cvavg = Math.Min(totalvavg, l22cvavg);
                                                        l22dvavg = Math.Min(totalvavg, l22dvavg);
                                                        l22evavg = Math.Min(totalvavg, l22evavg);
                                                        l31bvavg = Math.Min(totalvavg, l31bvavg);
                                                        l31cvavg = Math.Min(totalvavg, l31cvavg);
                                                        l31dvavg = Math.Min(totalvavg, l31dvavg);
                                                        l31evavg = Math.Min(totalvavg, l31evavg);
                                                        l32bvavg = Math.Min(totalvavg, l32bvavg);
                                                        l32cvavg = Math.Min(totalvavg, l32cvavg);
                                                        l32dvavg = Math.Min(totalvavg, l32dvavg);
                                                        l32evavg = Math.Min(totalvavg, l32evavg);
                                                        totalvavg = ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) * l11avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) * l12avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) * l11bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) * l12bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) * l11cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) * l12cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) * l11dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) * l12dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) * l11evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) * l12evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) * l21avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) * l22avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) * l21bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) * l22bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) * l21cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) * l22cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) * l21dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) * l22dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) * l21evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"]) * l22evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1acount"]) * l31avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2acount"]) * l32avavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bcount"]) * l31bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bcount"]) * l32bvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ccount"]) * l31cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ccount"]) * l32cvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dcount"]) * l31dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dcount"]) * l32dvavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ecount"]) * l31evavg +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ecount"]) * l32evavg
                                                              ) /
                                                              (Math.Max(1, (
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2acount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ccount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dcount"]) +
                                                              Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ecount"])
                                                            ))));
                                                        querystring = "INSERT INTO data ( " +
                                                            "mehvar_id, interval, " +
                                                            "acount, avavg, aspeed, agrab, aheadway, " +
                                                            "bcount, bvavg, bspeed, bgrab, bheadway, " +
                                                            "ccount, cvavg, cspeed, cgrab, cheadway, " +
                                                            "dcount, dvavg, dspeed, dgrab, dheadway, " +
                                                            "ecount, evavg, espeed, egrab, eheadway, " +
                                                            "xcount, xvavg, xspeed, xgrab, xheadway, " +
                                                            "count, vavg, speed, grab, headway, " +
                                                            "occ, vbat, vsol, errcode, processed, offpro" +
                                                            ") VALUES (" +
                                                            mehvar_code1.ToString() + ",'" + interval.ToString("yyyy-MM-ddTHH:mm:00.000") + "', " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2acount"])).ToString() + ", " +
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1avavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2avavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1avavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2avavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1acount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1avavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2acount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2avavg"])) / (Math.Max(1, Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2acount"])))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1aspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2aspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1aspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2aspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1aspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2aspeed"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1agrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2agrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1agrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2agrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1agrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2agrab"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1aheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2aheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1aheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2aheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1aheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2aheadway"])).ToString() + ", " +
                                                            //b
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bcount"])).ToString() + ", " +
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) * l11bvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) * l12bvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) * l21bvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) * l22bvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bcount"]) * l31bvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bcount"]) * l32bvavg) / (Math.Max(1, Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bcount"])))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bspeed"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bgrab"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bheadway"])).ToString() + ", " +
                                                            //c
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ccount"])).ToString() + ", " +
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) * l11cvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) * l12cvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) * l21cvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) * l22cvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ccount"]) * l31cvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ccount"]) * l32cvavg) / (Math.Max(1, Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ccount"])))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1cspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2cspeed"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1cgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2cgrab"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1cheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2cheadway"])).ToString() + ", " +
                                                            //d
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dcount"])).ToString() + ", " +
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) * l11dvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) * l12dvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) * l21dvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) * l22dvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dcount"]) * l31dvavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dcount"]) * l32dvavg) / (Math.Max(1, Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dcount"])))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dspeed"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dgrab"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dheadway"])).ToString() + ", " +
                                                            //e
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ecount"])).ToString() + ", " +
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) * l11evavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) * l12evavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) * l21evavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"]) * l22evavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ecount"]) * l31evavg + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ecount"]) * l32evavg) / (Math.Max(1, Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ecount"])))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1espeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2espeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1espeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2espeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1espeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2espeed"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1egrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2egrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1egrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2egrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1egrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2egrab"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1eheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2eheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1eheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2eheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1eheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2eheadway"])).ToString() + ", " +
                                                            //x
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2xcount"])).ToString() + ", " +
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xcount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xvavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xcount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xvavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xcount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xvavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xcount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xvavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1xcount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1xvavg"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2xcount"]) * Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2xvavg"])) / (Math.Max(1, Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1xcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2xcount"])))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1xspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2xspeed"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1xgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2xgrab"])).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1xheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2xheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1xheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2xheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1xheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2xheadway"])).ToString() + ", " +
                                                            //count
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2acount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bcount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ccount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dcount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2ecount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2acount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bcount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ccount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dcount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2ecount"])+
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1acount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2acount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bcount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ccount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ccount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dcount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dcount"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1ecount"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2ecount"])).ToString() + ", " +
                                                            //vavg
                                                            totalvavg.ToString() + ", " +
                                                            //speed
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1aspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2aspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1espeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2espeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1aspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2aspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1espeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2espeed"])+
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1aspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2aspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1cspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2cspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dspeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dspeed"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1espeed"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2espeed"])).ToString() + ", " +
                                                            //grab
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1agrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2agrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1egrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2egrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1agrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2agrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1egrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2egrab"])+
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1agrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2agrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1cgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2cgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dgrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dgrab"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1egrab"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2egrab"])).ToString() + ", " +
                                                            //headway
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1aheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2aheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1bheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2bheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1cheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2cheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1dheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2dheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1eheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2eheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1aheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2aheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1bheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2bheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1cheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2cheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1dheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2dheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1eheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2eheadway"])+
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1aheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2aheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1bheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2bheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1cheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2cheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1dheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2dheadway"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1eheadway"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2eheadway"])).ToString() + ", " +
                                                            //occ
                                                            ((Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l1occ"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["l2occ"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l1occ"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["l2occ"])+
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l1occ"]) +
                                                            Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["l2occ"])) / 6).ToString() + ", " +
                                                            (Math.Min((Math.Min(Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["vbat"]), Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["vbat"]))),Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["vbat"]))).ToString() + ", " +
                                                            (Math.Min((Math.Min(Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["vsol"]), Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["vsol"]))),Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["vsol"]))).ToString() + ", " +
                                                            (Convert.ToInt32(curr_data.Tables["Data"].Rows[0]["errcode"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[1]["errcode"]) + Convert.ToInt32(curr_data.Tables["Data"].Rows[2]["errcode"])).ToString() + ",0,0)";
                                                        //MessageBox.Show(querystring);
                                                        SqlDataAdapter adp2 = new SqlDataAdapter(querystring, con2);
                                                        DataSet curr_data2 = new DataSet();
                                                        adp2.Fill(curr_data2, "Data");
                                                    }
                                                    catch (Exception ss)
                                                    {
                                                        if (is_dubg) MessageBox.Show("88" + ss.Message);
                                                    }
                                                }
                                            }
                                        }

                                    }
                                }
                                catch (Exception ss)
                                {
                                    if (is_dubg) MessageBox.Show(data.ToString() + "99" + ss.ToString());
                                }




                            }
                        }
                        Thread.Sleep(500);
                    }
                }
                Thread.Sleep(300000);
                hansock.Close();
            }
            catch(Exception ss)
            {
                if (is_dubg) MessageBox.Show("1010" + ss.Message);
            }

        }
    }
}
